package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import  java.nio.MappedByteBuffer;
import  java.nio.channels.FileChannel;
import java.util.ArrayList;

public class RoomLocation extends AppCompatActivity {

    Button buttonR , buttonRM, buttonInfer ;
     Interpreter tflite;
     TextView txtRoom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_location);
        buttonR=(Button)findViewById(R.id.buttonseeR);
        buttonRM = (Button) findViewById(R.id.buttonnRooms);
        buttonInfer = (Button) findViewById(R.id.buttonInfer);
        txtRoom = (TextView) findViewById(R.id.textRoomName);
        final ArrayList<String> aList = new ArrayList<String>();
        aList.add("-73");
        aList.add("-72");
        aList.add("-70");
        aList.add("-67");
        aList.add("-65");
        aList.add("-100");
        aList.add("-74");
        aList.add("-100");
        aList.add("-59");
        aList.add("-66");
        aList.add("-74");
        aList.add("-100");
        aList.add("-74");
        aList.add("-100");
        aList.add("-71");
        aList.add("-74");
        aList.add("-100");
        aList.add("-74");
        aList.add("-66");
        aList.add("-100");
        aList.add("-72");
        aList.add("-74");
        aList.add("-72");
        aList.add("-100");
        buttonR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),RoomInformation.class);
                startActivity(i);
            }
        });

        buttonRM.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),NearbyRoomInformation.class);
                startActivity(i);
            }
        });

        try{
            tflite = new Interpreter(loadModelFile());
        }
        catch(Exception ex)
        {
             ex.printStackTrace();
        }

        buttonInfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String prediction = doInference(aList);
              txtRoom.setText(prediction);

            }
        });

    }
    public String doInference(ArrayList<String> array){
        String[] inputVal = new String[1];
        inputVal[0] =   String.valueOf(array.toString());

        String[][] outputval = new String[1][1];

        tflite.run(inputVal,outputval);
        String inferredValue = outputval[0][0];
        return  inferredValue;

    }

    private MappedByteBuffer  loadModelFile() throws IOException{
        AssetFileDescriptor fileDescriptor = this.getAssets().openFd("converted_model.tflite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startoffset = fileDescriptor.getStartOffset();
        long declaredlenght = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY,startoffset, declaredlenght);
    }
}
