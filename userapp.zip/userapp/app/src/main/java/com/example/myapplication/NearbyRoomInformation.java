package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NearbyRoomInformation extends AppCompatActivity {

    Button buttonLeft , buttonRight, buttonUp, buttonDown ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby_room_information);

        buttonLeft=(Button)findViewById(R.id.btnRoomLeft);
        buttonRight = (Button) findViewById(R.id.btnRoomRight);
        buttonUp=(Button)findViewById(R.id.btnRoomUp);
        buttonDown = (Button) findViewById(R.id.btnRoomDown);

        buttonRight.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),RoomInformation.class);
                startActivity(i);
            }
        });
        buttonLeft.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),RoomInformation.class);
                startActivity(i);
            }
        });  buttonUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),RoomInformation.class);
                startActivity(i);
            }
        });  buttonDown.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getApplicationContext(),RoomInformation.class);
                startActivity(i);
            }
        });
    }
}
