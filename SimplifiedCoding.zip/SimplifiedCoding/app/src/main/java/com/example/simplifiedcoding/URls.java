package com.example.simplifiedcoding;

public class URls {
    private static final String ROOT_URL = "http://10.5.5.56/test/Api.php?apicall=";

    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN= ROOT_URL + "login";

}
